#!/bin/bash

gcc main.c ArvoreBinaria.c -o lala
./lala