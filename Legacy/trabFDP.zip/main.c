#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "LDED.h"

FILE *Arq;

int main()
{
    Elem  *el;
    //Lista *li = cria_lista();
    
    ///////////////////////////////////
    LISTA_LIGADA *lista = criar_lista();
    //LISTA_LIGADA *lista2 = criar_lista();
    //char *ptr1 = "lala";
    //char *ptr2 = "lolo";
    //inserir_item_inicio(lista, ptr1);
    //inserir_item_inicio(lista, ptr2);
    //exibe(lista);    
    ///////////////////////////////////

    char *arquivoEscolhido = (char*)malloc(sizeof (char)*5); 	// a string do arquivo escolhido tem seu tamanho alocado dinamicamente para receber
    															//os caracteres '.' 'e' 'x' 't' e abrir o arquivo

    char buffer;		//buffer e count sao usados para que se contar quantos caracteres estão presentes no arquivo de texto
    int count = 0;
    int i;
    int aux = 0;
    int k;
       

    printf("escolha o arquivo\n");
    scanf("%c", &arquivoEscolhido[0]);
    
    arquivoEscolhido[1] = '.';
    arquivoEscolhido[2] = 'e';
    arquivoEscolhido[3] = 'x';
    arquivoEscolhido[4] = 't';

    //printf("%s\n", arquivoEscolhido);
    printf("lalalla\n");

    Arq = fopen(arquivoEscolhido, "r");
    

    buffer = fgetc(Arq);
    
    while (!feof(Arq))
    {
    	count++;
    	buffer = fgetc(Arq);
    }
    printf("lalallaal 2\n");
    
    rewind(Arq);

    char *texto = (char*)malloc(sizeof (char)*count);
	char *sbuffer = (char *)malloc(sizeof(char)*10);
    //char sbuffer[10]; 
    
    ///AQUI EH FEITA A LEITURA DAS PALAVRAS DO ARQUIVO
    ///CADA CARACTERE EH LIDO E COLOCADO NA VARIAVEL TEXTO, E DEPOIS DO TEXTO PARA O SBUFFER
    ///QUANDO UM UM CARATERE DE ESPACO EH ENCONTRADO TUDO QUE ESTA NO SBUFFER EH INSERIDO NA LISTA

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    for(i = 0; i < count; i++)
	{
        texto[i] = fgetc(Arq);
		//printf("%d   %c\n", i, texto[i]);

		if(texto[i] != ' ')
		{
			sbuffer[aux] = texto[i];
            aux++;
			printf("sbuffer se formando %s\n", sbuffer);

		}
        
		if(texto[i] == ' ')
		{
            //aux = 0;
            printf("\nisso que ta no buffer %s\n", sbuffer);
            
            
            exibe(lista);
            inserir_item_fim(lista, sbuffer);
            
            aux = 0;


            exibe(lista);
            
            inserir_item_inicio(lista, "primeiro");
            inserir_item_fim(lista, "segundo");

            
            exibe(lista);
            
            for(k = 0; k < count; k++)
                sbuffer[k] = 0;
            printf("\nisso depois de tentar zerar++++++++++++ %c\n", sbuffer[2]);
            exibe(lista);   
		}

	}
    
    /////////////////////////////////////////////////////////////////////////////////////////////////
    //exibe(lista);
   
    inserir_item_fim(lista, "He000o");
    inserir_item_fim(lista, "Wo333");
   
    exibe(lista);

    ///ESSA PARTE AQUI PARA BAIXO EH APENAS PARA TESTE E VERIFICACAO DAS FUNCOES DO TAD
    char *pal = (char *)malloc(sizeof (char)*10);
    char *pal2 = (char *)malloc(sizeof (char)*8);
    pal = "lolo";

    inserir_item_fim(lista, pal);
    exibe(lista);

    printf("palavra 1: %s\n", pal);
    printf("isso eh antes paara a pal2 : %s\n", pal2);
    pal2 = pal;
    inserir_item_fim(lista, pal2);
    exibe(lista);
    pal = "wawa";
    exibe(lista);
    printf("palavra  %s \n", pal);
 
    ////////////////////////////////////////////////////////////////////////////////////
   
    /*
    while(comando != 's')
    {
    	printf("O que vc quer fazer?\n");
    	printf("i -> insere palavra no anterior\n");
		printf("a -> insere palavra no posterior\n");    			
    	printf("r -> substitui palavra do no atual\n");
    	printf("f -> busca palavra identica mais proxima\n");
    	printf("d: -> remove palavra atual\n");
    	printf("n: -> avanca o editor em uma posicao\n");
    	printf("p: -> retrocede o cursos em uma posicao\n");
    	printf("b: -> posiciona o cursor no inicio\n");
    	printf("e: -> posiciona o cursos no final\n");
    	printf("g -> avanca/retrocede o cursor numero especificado\n");
    	printf("s -> imprime tudo e finaliza programa\n");
    	
    	//scanf("%c", &comando);

    	printf("O comando escolhido foi %c\n\n", comando);

    	printf("Escolha o arquivo:\n");


    	if(comando == 'i')
    }
    
	*/
    




    //free(sbuffer);
    //free(texto);

    fclose(Arq);

   
    return 0;
}

